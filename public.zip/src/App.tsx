import React from "react";
import "./App.css";
import PGABRiskForm from "./PGABRiskForm";

function App() {
  return <PGABRiskForm />;
}

export default App;
